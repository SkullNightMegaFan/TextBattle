#include <stdio.h>
#include <stdlib.h>
#include <cstdio>

int main()
{
	const char* heroName = "Ness";
	int heroHp = 38;
	int heroPsi = 16;
	int healSpellcost = 4;
	int healSpeallPower = 35;
	int heroAttackPower = 12;

	const char* narrarator = "The Creator";
	int narratorPower = 150;


	const char* monsterName = "Funky Hippie";
	int monsterHp = 36;
	int monsterPower = 20;

	printf("A %s drunkely draws near!\n", monsterName);
	printf("\n");

	while(monsterHp > 0 && heroHp > 0)
	{ 
		printf("=======\n");
		printf("[%s HP: %d, PSI %d]\n", heroName, heroHp, heroPsi);
		printf("[%s HP: %d]\n", monsterName, monsterHp);
		printf("\n");

		printf("Command?\n");
		printf("1 -> Attack(No PSI Cost)\n");
		printf("2 -> Heal (PSI Cost: %d)\n", healSpellcost);
		printf(">");

		int choice = 0;
		scanf_s("%d", &choice);
		printf("\n");

		////////////PLAYER INPUT/////////////////////////
		if (choice == 1)
		{
			int monsterPower = 10;
			printf("\n%s attacks!\n", heroName);
			printf("\nThe %s' Hit Points decreased by %d\n", monsterName, heroAttackPower);
			printf("\n");

			monsterHp = monsterHp - heroAttackPower;
		}
		else if (choice == 2)
		{
			int monsterPower = 10;
			printf("\n%s casts Heal!\n", heroName);
			printf("\n%s' Hit Points have increased by %d", heroName, healSpeallPower);
			printf("\n");
			heroHp = heroHp + healSpeallPower;
			heroPsi = heroPsi - healSpellcost;
		}	
		else if (choice == 69)
		{
			printf("You think you're sooooooooooooooo funny.\n");
			printf("\nWell if you think that's funny how about you restart the game!!!\n");
			printf("%s deals a fatal blow!\n", narrarator);
			printf("%s' Hit Points decreased by %d!\n", heroName, narratorPower);
			printf("\n");
			heroHp = heroHp - narratorPower;
		}
		else 
		{
			printf("HEY STOP THAT. PLAY THE GAME RIGHT!!! >:(\n");
			printf("\nPress either 1 or 2 to proceed with the battle!!!\n");
		    monsterPower = 5;
			printf("\n");
		}


		if (monsterHp > 0)
		{
			printf("The %s attacks!\n", monsterName);
			printf("%s loses %d health points!\n", heroName, monsterPower);
			printf("\n");
			heroHp = heroHp - monsterPower;
		}
		
		
	}
	
	if (heroHp > 0 && monsterHp <= 0)
	{

		printf("***********\n");
		printf("You fought off your first  drunk %s, congratulations!\n", monsterName);
		printf("You gained 20 followers on Instagram!\n");
		printf("\n");
	}
	else if (heroHp < -30)
	{
		printf("You fool, how dare you try to resist the program!!!\n");
		printf("Now you are forced to wonder the void forever\n");
		printf("MWAHAHAHAHAHAHA");
		printf("\n");
	}
	else if (monsterHp > 0)
	{
		printf("!!!!!!!!!!!!!!!!!!!!!!!\n");
		printf("You have perished!\n");
		printf("That wasn't very cash money of you, try again!!!\n");

	}
	system("pause");
	return 0;
}